﻿namespace QLSV
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_MaSV = new System.Windows.Forms.Label();
            this.lb_HoTen = new System.Windows.Forms.Label();
            this.lb_NgaySinh = new System.Windows.Forms.Label();
            this.lb_NoiSinh = new System.Windows.Forms.Label();
            this.lb_GioiTinh = new System.Windows.Forms.Label();
            this.tb_MaSV = new System.Windows.Forms.TextBox();
            this.tb_HoTen = new System.Windows.Forms.TextBox();
            this.cb_NoiSinh = new System.Windows.Forms.ComboBox();
            this.rd_Nam = new System.Windows.Forms.RadioButton();
            this.rd_Nu = new System.Windows.Forms.RadioButton();
            this.dtime_NgaySinh = new System.Windows.Forms.DateTimePicker();
            this.bt_Them = new System.Windows.Forms.Button();
            this.bt_Sua = new System.Windows.Forms.Button();
            this.bt_Xoa = new System.Windows.Forms.Button();
            this.bt_Loc = new System.Windows.Forms.Button();
            this.grb_ThongTinChiTiet = new System.Windows.Forms.GroupBox();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.bt_Thoat = new System.Windows.Forms.Button();
            this.grb_ThongTinChiTiet.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_MaSV
            // 
            this.lb_MaSV.AutoSize = true;
            this.lb_MaSV.Location = new System.Drawing.Point(108, 53);
            this.lb_MaSV.Name = "lb_MaSV";
            this.lb_MaSV.Size = new System.Drawing.Size(76, 25);
            this.lb_MaSV.TabIndex = 0;
            this.lb_MaSV.Text = "Mã SV";
            // 
            // lb_HoTen
            // 
            this.lb_HoTen.AutoSize = true;
            this.lb_HoTen.Location = new System.Drawing.Point(108, 138);
            this.lb_HoTen.Name = "lb_HoTen";
            this.lb_HoTen.Size = new System.Drawing.Size(82, 25);
            this.lb_HoTen.TabIndex = 1;
            this.lb_HoTen.Text = "Họ Tên";
            // 
            // lb_NgaySinh
            // 
            this.lb_NgaySinh.AutoSize = true;
            this.lb_NgaySinh.Location = new System.Drawing.Point(108, 208);
            this.lb_NgaySinh.Name = "lb_NgaySinh";
            this.lb_NgaySinh.Size = new System.Drawing.Size(111, 25);
            this.lb_NgaySinh.TabIndex = 2;
            this.lb_NgaySinh.Text = "Ngày Sinh";
            // 
            // lb_NoiSinh
            // 
            this.lb_NoiSinh.AutoSize = true;
            this.lb_NoiSinh.Location = new System.Drawing.Point(618, 56);
            this.lb_NoiSinh.Name = "lb_NoiSinh";
            this.lb_NoiSinh.Size = new System.Drawing.Size(93, 25);
            this.lb_NoiSinh.TabIndex = 3;
            this.lb_NoiSinh.Text = "Nơi Sinh";
            // 
            // lb_GioiTinh
            // 
            this.lb_GioiTinh.AutoSize = true;
            this.lb_GioiTinh.Location = new System.Drawing.Point(627, 138);
            this.lb_GioiTinh.Name = "lb_GioiTinh";
            this.lb_GioiTinh.Size = new System.Drawing.Size(98, 25);
            this.lb_GioiTinh.TabIndex = 4;
            this.lb_GioiTinh.Text = "Giới Tính";
            // 
            // tb_MaSV
            // 
            this.tb_MaSV.Location = new System.Drawing.Point(273, 50);
            this.tb_MaSV.Name = "tb_MaSV";
            this.tb_MaSV.Size = new System.Drawing.Size(243, 31);
            this.tb_MaSV.TabIndex = 5;
            // 
            // tb_HoTen
            // 
            this.tb_HoTen.Location = new System.Drawing.Point(273, 132);
            this.tb_HoTen.Name = "tb_HoTen";
            this.tb_HoTen.Size = new System.Drawing.Size(243, 31);
            this.tb_HoTen.TabIndex = 6;
            // 
            // cb_NoiSinh
            // 
            this.cb_NoiSinh.FormattingEnabled = true;
            this.cb_NoiSinh.Items.AddRange(new object[] {
            "HA NOI",
            "HCM",
            "HAI DUONG",
            "BAC NINH"});
            this.cb_NoiSinh.Location = new System.Drawing.Point(726, 48);
            this.cb_NoiSinh.Name = "cb_NoiSinh";
            this.cb_NoiSinh.Size = new System.Drawing.Size(280, 33);
            this.cb_NoiSinh.TabIndex = 8;
            // 
            // rd_Nam
            // 
            this.rd_Nam.AutoSize = true;
            this.rd_Nam.Location = new System.Drawing.Point(731, 138);
            this.rd_Nam.Name = "rd_Nam";
            this.rd_Nam.Size = new System.Drawing.Size(87, 29);
            this.rd_Nam.TabIndex = 9;
            this.rd_Nam.TabStop = true;
            this.rd_Nam.Text = "Nam";
            this.rd_Nam.UseVisualStyleBackColor = true;
            this.rd_Nam.CheckedChanged += new System.EventHandler(this.rd_Nam_CheckedChanged);
            // 
            // rd_Nu
            // 
            this.rd_Nu.AutoSize = true;
            this.rd_Nu.Location = new System.Drawing.Point(835, 138);
            this.rd_Nu.Name = "rd_Nu";
            this.rd_Nu.Size = new System.Drawing.Size(70, 29);
            this.rd_Nu.TabIndex = 10;
            this.rd_Nu.TabStop = true;
            this.rd_Nu.Text = "Nữ";
            this.rd_Nu.UseVisualStyleBackColor = true;
            this.rd_Nu.CheckedChanged += new System.EventHandler(this.rd_Nu_CheckedChanged);
            // 
            // dtime_NgaySinh
            // 
            this.dtime_NgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtime_NgaySinh.Location = new System.Drawing.Point(273, 202);
            this.dtime_NgaySinh.Name = "dtime_NgaySinh";
            this.dtime_NgaySinh.Size = new System.Drawing.Size(243, 31);
            this.dtime_NgaySinh.TabIndex = 11;
            // 
            // bt_Them
            // 
            this.bt_Them.Location = new System.Drawing.Point(623, 221);
            this.bt_Them.Name = "bt_Them";
            this.bt_Them.Size = new System.Drawing.Size(97, 38);
            this.bt_Them.TabIndex = 12;
            this.bt_Them.Text = "Thêm";
            this.bt_Them.UseVisualStyleBackColor = true;
            this.bt_Them.Click += new System.EventHandler(this.bt_Them_Click);
            // 
            // bt_Sua
            // 
            this.bt_Sua.Location = new System.Drawing.Point(757, 221);
            this.bt_Sua.Name = "bt_Sua";
            this.bt_Sua.Size = new System.Drawing.Size(97, 38);
            this.bt_Sua.TabIndex = 13;
            this.bt_Sua.Text = "Sửa";
            this.bt_Sua.UseVisualStyleBackColor = true;
            this.bt_Sua.Click += new System.EventHandler(this.bt_Sua_Click);
            // 
            // bt_Xoa
            // 
            this.bt_Xoa.Location = new System.Drawing.Point(871, 221);
            this.bt_Xoa.Name = "bt_Xoa";
            this.bt_Xoa.Size = new System.Drawing.Size(97, 38);
            this.bt_Xoa.TabIndex = 14;
            this.bt_Xoa.Text = "Xóa";
            this.bt_Xoa.UseVisualStyleBackColor = true;
            this.bt_Xoa.Click += new System.EventHandler(this.bt_Xoa_Click);
            // 
            // bt_Loc
            // 
            this.bt_Loc.Location = new System.Drawing.Point(984, 221);
            this.bt_Loc.Name = "bt_Loc";
            this.bt_Loc.Size = new System.Drawing.Size(97, 38);
            this.bt_Loc.TabIndex = 15;
            this.bt_Loc.Text = "Lọc";
            this.bt_Loc.UseVisualStyleBackColor = true;
            this.bt_Loc.Click += new System.EventHandler(this.bt_Loc_Click);
            // 
            // grb_ThongTinChiTiet
            // 
            this.grb_ThongTinChiTiet.Controls.Add(this.dgv);
            this.grb_ThongTinChiTiet.Location = new System.Drawing.Point(113, 287);
            this.grb_ThongTinChiTiet.Name = "grb_ThongTinChiTiet";
            this.grb_ThongTinChiTiet.Size = new System.Drawing.Size(1026, 440);
            this.grb_ThongTinChiTiet.TabIndex = 16;
            this.grb_ThongTinChiTiet.TabStop = false;
            this.grb_ThongTinChiTiet.Text = "Thông Tin Chi Tiết";
            // 
            // dgv
            // 
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(0, 0);
            this.dgv.Name = "dgv";
            this.dgv.RowHeadersWidth = 82;
            this.dgv.RowTemplate.Height = 33;
            this.dgv.Size = new System.Drawing.Size(1020, 440);
            this.dgv.StandardTab = true;
            this.dgv.TabIndex = 0;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            // 
            // bt_Thoat
            // 
            this.bt_Thoat.Location = new System.Drawing.Point(1109, 221);
            this.bt_Thoat.Name = "bt_Thoat";
            this.bt_Thoat.Size = new System.Drawing.Size(97, 38);
            this.bt_Thoat.TabIndex = 17;
            this.bt_Thoat.Text = "Thoát";
            this.bt_Thoat.UseVisualStyleBackColor = true;
            this.bt_Thoat.Click += new System.EventHandler(this.bt_Thoat_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1218, 778);
            this.Controls.Add(this.bt_Thoat);
            this.Controls.Add(this.grb_ThongTinChiTiet);
            this.Controls.Add(this.bt_Loc);
            this.Controls.Add(this.bt_Xoa);
            this.Controls.Add(this.bt_Sua);
            this.Controls.Add(this.bt_Them);
            this.Controls.Add(this.dtime_NgaySinh);
            this.Controls.Add(this.rd_Nu);
            this.Controls.Add(this.rd_Nam);
            this.Controls.Add(this.cb_NoiSinh);
            this.Controls.Add(this.tb_HoTen);
            this.Controls.Add(this.tb_MaSV);
            this.Controls.Add(this.lb_GioiTinh);
            this.Controls.Add(this.lb_NoiSinh);
            this.Controls.Add(this.lb_NgaySinh);
            this.Controls.Add(this.lb_HoTen);
            this.Controls.Add(this.lb_MaSV);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Sinh Viên";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grb_ThongTinChiTiet.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_MaSV;
        private System.Windows.Forms.Label lb_HoTen;
        private System.Windows.Forms.Label lb_NgaySinh;
        private System.Windows.Forms.Label lb_NoiSinh;
        private System.Windows.Forms.Label lb_GioiTinh;
        private System.Windows.Forms.TextBox tb_MaSV;
        private System.Windows.Forms.TextBox tb_HoTen;
        private System.Windows.Forms.ComboBox cb_NoiSinh;
        private System.Windows.Forms.RadioButton rd_Nam;
        private System.Windows.Forms.RadioButton rd_Nu;
        private System.Windows.Forms.DateTimePicker dtime_NgaySinh;
        private System.Windows.Forms.Button bt_Them;
        private System.Windows.Forms.Button bt_Sua;
        private System.Windows.Forms.Button bt_Xoa;
        private System.Windows.Forms.Button bt_Loc;
        private System.Windows.Forms.GroupBox grb_ThongTinChiTiet;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button bt_Thoat;
    }
}

