﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;
using System.Collections;

namespace QLSV
{
    public partial class Form1 : Form
    {
        SqlConnection connection;
        SqlCommand command;
        string str = @"Data Source=HOAIEM\MSQLEXPRESS;Initial Catalog=QLSV1;Integrated Security=True;Encrypt=False";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable dt = new DataTable();
        int vitrichon;
        string checkedGioiTinh;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            command = new SqlCommand("SELECT * FROM SINHVIEN", connection);
            adapter = new SqlDataAdapter(command);
            adapter.Fill(dt);
            dgv.DataSource = dt;
        }

    
        private void bt_Xoa_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            command = new SqlCommand("DELETE FROM SINHVIEN WHERE MASV  = N'" + tb_MaSV.Text + "';", connection);
            command.ExecuteNonQuery();
        }

        private void bt_Loc_Click(object sender, EventArgs e)
        {
            try
            {
                string maSV = tb_MaSV.Text.Trim();

                if (maSV == "")
                {
                    MessageBox.Show("Vui lòng nhập mã sinh viên để tìm kiếm.", "Thông báo");
                    return;
                }

                connection = new SqlConnection(str);
                connection.Open();
                command = new SqlCommand("SELECT * FROM SINHVIEN WHERE MASV = @MaSV", connection);
                command.Parameters.AddWithValue("@MaSV", maSV);

                adapter.SelectCommand = command;
                dt.Clear();
                adapter.Fill(dt);
                dgv.DataSource = dt;

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Không tìm thấy sinh viên với mã " + maSV, "Thông báo");
                    tb_MaSV.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tìm kiếm sinh viên: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }


        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                vitrichon = e.RowIndex;
                if (vitrichon >= 0)
                {
                    tb_MaSV.Text = dt.Rows[vitrichon][0].ToString();
                    tb_HoTen.Text = dt.Rows[vitrichon][1].ToString();
                    dtime_NgaySinh.Value = Convert.ToDateTime(dt.Rows[vitrichon][2].ToString());
                    cb_NoiSinh.Text = dt.Rows[vitrichon][3].ToString();
                    string gioiTinh = dt.Rows[vitrichon][4].ToString();
                    if (gioiTinh.Trim() == "Nam")
                    {
                        rd_Nam.Checked = true;
                    }
                    else if (gioiTinh.Trim() == "Nữ")
                    {
                        rd_Nu.Checked = true;
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Vui lòng chọn dòng hợp lệ!", "Lỗi");
            }
        }


        private void rd_Nam_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_Nam.Checked)
            {
                checkedGioiTinh = rd_Nam.Text;
            }
        }

        private void rd_Nu_CheckedChanged(object sender, EventArgs e)
        {
            if (rd_Nu.Checked)
            {
                checkedGioiTinh = rd_Nu.Text;
            }
        }

        private void bt_Them_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(str))
                {
                    connection.Open();
                    string query = "INSERT INTO SINHVIEN VALUES(@MaSV, @HoTen, @NgaySinh, @NoiSinh, @GioiTinh)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@MaSV", tb_MaSV.Text);
                    command.Parameters.AddWithValue("@HoTen", tb_HoTen.Text);
                    command.Parameters.AddWithValue("@NgaySinh", dtime_NgaySinh.Value);
                    command.Parameters.AddWithValue("@NoiSinh", cb_NoiSinh.Text);
                    command.Parameters.AddWithValue("@GioiTinh", checkedGioiTinh);
                    command.ExecuteNonQuery();
                }
                MessageBox.Show("Thêm sinh viên thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi");
            }
        }

        private void bt_Sua_Click(object sender, EventArgs e)
        {
            try
            {
                connection = new SqlConnection(str);
                connection.Open();
                command = new SqlCommand("UPDATE SINHVIEN SET HoTen = N'" + tb_HoTen.Text + "', NgaySinh = '" + dtime_NgaySinh.Value.ToString("yyyy-MM-dd") + "', NoiSinh = N'" + cb_NoiSinh.Text + "', GioiTinh = N'" + checkedGioiTinh + "' WHERE MASV = N'" + tb_MaSV.Text + "'", connection);
                command.ExecuteNonQuery();
                MessageBox.Show("Sửa thông tin sinh viên thành công!");
                dt.Clear();
                adapter.Fill(dt);
                dgv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi sửa thông tin sinh viên: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void bt_Thoat_Click(object sender, EventArgs e)
        {

        }
    }

}
